CHS:
地图类型：缩圈地图
最大玩家数：20
描述：此类地图共有9张地图，每张地图的最终毒圈都不一样(目前地图作者尚未弄清楚随机毒圈的刷新原理),因此您可以凭借地图名称含"A-I"的地图序号，与预览图对应，从而得知最终圈的刷新位置。
----------------------------------------------------------------------------
made by Qiuye
2023/4/16

EN:
Map Type: Circled map
Maximum number of players: 20
Description: There are 9 maps in this type of map, and each map has a different final Safe Zone of poison (the map author has not yet figured out how the random Safe Zone refreshes), so you can use the map number with "A-I" in the map name to correspond to the preview map, so as to know the refresh location of the final Safe Zone.
----------------------------------------------------------------------------
made by Qiuye
2023/4/16